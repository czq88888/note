package com.caozhiqiang.engine.esb.action;

import org.apache.log4j.Logger;
import weaver.conn.RecordSet;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 天气预报流程插入初始明细表日期数据
 *
 * @author caozhiqiang
 * @date 2019/8/2
 */
public class InsertWeatherDetailAction implements Action {
    private RecordSet rs = new RecordSet();
    private Logger log = Logger.getLogger(InsertWeatherDetailAction.class);

    @Override
    public String execute(RequestInfo request) {
        int billid = request.getRequestManager().getBillid();
        String tableName = request.getRequestManager().getBillTableName();
        rs.execute("delete from " + tableName + "_dt1 where mainid=" + billid);
        int flag = 2;
        String sql = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        while (true) {
            sql = "insert into " + tableName + "_dt1(mainid,rq,rq2,xqj) values(" + billid + "," +
                    "'" + flag + "日" + getWeekOfDate(c.getTime()) + "'," +
                    "'" + sdf.format(c.getTime()) + "','" + getWeekOfDate(c.getTime()) + "')";
            log.info(sql);
            rs.execute(sql);
            c.add(Calendar.DAY_OF_MONTH, 1);
            flag++;
            if (flag == 7) break;

        }

        return Action.SUCCESS;
    }

    /**
     * 获取当前日期是星期几
     *
     * @param dt
     * @return 当前日期是星期几
     */
    public static String getWeekOfDate(Date dt) {
        String[] weekDays = {"星期天", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
        Calendar cal = Calendar.getInstance();
        cal.setTime(dt);
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0)
            w = 0;
        return weekDays[w];
    }


}
