package com.caozhiqiang.engine.esb.logging;

/**
 * 自定义日志接口
 *
 * @author Cho
 * @date 2019/8/6
 */
public interface Logger {
    boolean isDebugEnabled();

    void debug(Object obj);

    void debug(Object obj, Throwable throwable);

    boolean isInfoEnabled();

    void info(Object obj);

    void info(Object obj, Throwable throwable);

    void warn(Object obj);

    void warn(Object obj, Throwable throwable);

    void error(Object obj);

    void error(Object obj, Throwable throwable);

    String getClassname();

    void setClassname(String classname);

    void init(String loggerName);
}
