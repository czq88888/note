package com.caozhiqiang.engine.esb.logging;


/**
 * 自定义日志工厂
 *
 * @author bijin
 * @date 2019-08-10
 */
public class LoggerFactory {
    private static final String loggerName = "dev";

    public LoggerFactory() {
    }

    public static Logger getLogger(String loggerName, String classname) {
        if ("".equals(loggerName)) {
            loggerName = "oreo";
        }

        Log4JLogger log4JLogger = new Log4JLogger();
        log4JLogger.setClassname(classname);
        log4JLogger.init(loggerName);
        return log4JLogger;
    }

    public static Logger getLogger(Class classObj) {
        return getLogger(loggerName, classObj.getCanonicalName());
    }

    public static Logger getLogger(String content) {
        return getLogger(loggerName, content);
    }

    public static Logger getLogger() {
        String className = Thread.currentThread().getStackTrace()[2].getClassName();
        return getLogger(loggerName, className);
    }
}
