package com.caozhiqiang.engine.esb.test;

import weaver.conn.RecordSetDataSource;
import weaver.general.Util;

/**
 * 存储过程调用测试
 *
 * @author bijin
 * @date 2019-08-11
 */
public class ProcTest {
    char separator = Util.getSeparator();

    public void testProc() {
        //使用名称为ds的数据源
        RecordSetDataSource rsds = new RecordSetDataSource("leida_oa");
        rsds.executeProc("Base_FreeField_Select", "p1");
        String[] colNames = rsds.getColumnName();
        while (rsds.next()) {
            for (String colname : colNames) {
                System.out.println(colname + "=" + rsds.getString(colname));
            }
        }
    }

    public void testProc2(String complete) {
        String userid = "1";
        String wftype = "14";
        String workflowid = "66";
        //使用名称为ds的数据源
        RecordSetDataSource rsds = new RecordSetDataSource("leida_oa");
        rsds.executeProc("workflow_requestbase_Select", userid + separator + wftype + separator + workflowid + separator + complete);
        String[] colNames = rsds.getColumnName();
        while (rsds.next()) {
            for (String colname : colNames) {
                System.out.println(colname + "=" + rsds.getString(colname));
            }
        }
        System.out.println(rsds.getFlag());
        System.out.println(rsds.getMsg());
    }
}
