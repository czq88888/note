package com.caozhiqiang.engine.test.log;

import com.engine.kq.log.KQLog;
import weaver.formmode.log.FormmodeLog;
import weaver.integration.logging.Logger;
import weaver.integration.logging.LoggerFactory;

/**
 * @author Cho
 * @date 2019/8/6
 */
public class LogTest {

    public void printLog(){
        Logger log = LoggerFactory.getLogger(LogTest.class);
        log.info("integration");

        FormmodeLog formmodeLog = new FormmodeLog();
        formmodeLog.writeLog("formmode");

        org.apache.log4j.Logger log2 = org.apache.log4j.Logger.getLogger(LogTest.class);
        log2.info("arg.apache.log4j.Logger");

        weaver.multilang.logging.Logger log3 = weaver.multilang.logging.LoggerFactory.getLogger(LogTest.class);
        log3.info("multilang");

        weaver.backup.logging.Logger log4 = weaver.backup.logging.LoggerFactory.getLogger(LogTest.class);
        log4.info("bakcup");

        weaver.portal.logging.PortalLogger log5 = weaver.portal.logging.PortalLoggerFactory.getLogger(LogTest.class);
        log5.info("protal");

        KQLog kqLog = new KQLog();
        kqLog.info("hrmkq");

        Logger log6 =LoggerFactory.getLogger(LogTest.class);
        log6.info("oreo");

    }
}
