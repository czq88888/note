package com.caozhiqiang.engine.esb.util;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Arrays;
import java.util.Map;

/**
 * ESB工具
 *
 * @author Cho
 * @date 2019/8/6
 */
public class ESBUtil {

    /**
     * 签名算法
     *
     * @param params
     * @param secret
     * @return
     */
    public static String sign(Map<String, String> params, String secret) {
        // 第一步：检查参数是否已经排序
        String[] keys = params.keySet().toArray(new String[0]);
        Arrays.sort(keys);
        // 第二步：把所有参数名和参数值串在一起
        StringBuilder query = new StringBuilder();
        for (String key : keys) {
            if (key != null && !key.isEmpty()) {
                String value = params.get(key);
                if (value != null && !value.isEmpty()) {
                    query.append(key).append(value);
                }
            }
        }
        // 第三步：使⽤用HMAC加密
        byte[] bytes = encryptHMAC(query.toString(), secret);
        // 第四步：把二进制转化为大写的十六进制(正确签名应该为32大写字符串，此⽅方法需要时使用)
        return byte2hex(bytes);
    }

    /**
     * 使用HMAC加密
     *
     * @param data
     * @param secret
     * @return
     */
    private static byte[] encryptHMAC(String data, String secret) {
        byte[] bytes = null;
        try {
            SecretKey secretKey = new SecretKeySpec(secret.getBytes(), "HmacMD5");
            Mac mac = Mac.getInstance(secretKey.getAlgorithm());
            mac.init(secretKey);
            bytes = mac.doFinal(data.getBytes());
        } catch (Exception e) {
        }
        return bytes;
    }

    /**
     * 二进制转化为大写的十六进制
     *
     * @param bytes
     * @return
     */
    private static String byte2hex(byte[] bytes) {
        StringBuilder sign = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            String hex = Integer.toHexString(bytes[i] & 0xFF);
            if (hex.length() == 1) {
                sign.append("0");
            }
            sign.append(hex.toUpperCase());
        }
        return sign.toString();
    }
}
