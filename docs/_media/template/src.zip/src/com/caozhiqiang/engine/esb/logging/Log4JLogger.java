package com.caozhiqiang.engine.esb.logging;

import com.caozhiqiang.engine.esb.logging.Logger;

/**
 * 自定义日志
 *
 * @author bijin
 * @date 2019/8/6
 */
public class Log4JLogger implements Logger {

    private org.apache.log4j.Logger log;
    /** 类名 */
    private String classname;

    public Log4JLogger() {
    }

    public String getClassname() {
        return this.classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public boolean isDebugEnabled() {
        return this.log.isDebugEnabled();
    }

    public boolean isInfoEnabled() {
        return this.log.isInfoEnabled();
    }

    public void debug(Object obj) {
        String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        this.log.debug(this.classname + "." + methodName + "() - " + obj);
    }

    public void debug(Object obj, Throwable throwable) {
        String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        this.log.debug(this.classname + "." + methodName + "() - " + obj, throwable);
    }

    public void info(Object obj) {
        String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        this.log.info(this.classname + "." + methodName + "() - " + obj);
    }

    public void info(Object obj, Throwable throwable) {
        String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        this.log.info(this.classname + "." + methodName + "() - " + obj, throwable);
    }

    public void warn(Object obj) {
        String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        this.log.warn(this.classname + "." + methodName + "() - " + obj);
    }

    public void warn(Object obj, Throwable throwable) {
        String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        this.log.warn(this.classname + "." + methodName + "() - " + obj, throwable);
    }

    public void error(Object obj) {
        String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        this.log.error(this.classname + "." + methodName + "() - " + obj);
    }

    public void error(Object obj, Throwable throwable) {
        String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        this.log.error(this.classname + "." + methodName + "() - " + obj, throwable);
    }

    public void init(String loggerName) {
        if ("".equals(loggerName)) {
            loggerName = "oreo";
        }

        this.log = org.apache.log4j.Logger.getLogger(loggerName);
    }
}
