package com.caozhiqiang.engine.esb.test.job;

import weaver.interfaces.schedule.BaseCronJob;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Cho
 * @date 2019/7/26
 */
public class JobTest extends BaseCronJob {
    private String jobName;

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    @Override
    public void execute() {
        SimpleDateFormat var1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        try {
            Thread.sleep(5000L);
        } catch (InterruptedException var3) {
            var3.printStackTrace();
        }
        System.out.println("==================execute " + this.getJobName() + " at " + var1.format(new Date()));
    }
}
