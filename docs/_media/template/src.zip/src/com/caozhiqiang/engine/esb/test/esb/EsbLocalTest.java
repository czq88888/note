package com.caozhiqiang.engine.esb.test.esb;

import com.weaver.esb.spi.EsbManager;
import com.weaver.esb.spi.EsbService;
import com.weaver.esb.spi.RequestConfig;

public class EsbLocalTest {
    private String appKey = "64caed2d-ab47-4116-b1be-6caec02a2fa1";
    private String serverUrl;
    private String sercetKey = "e79cf12c0e2304ecfec2c72db34acc71";
    private String userName = "sysadmin";
    private String password = "1";
    private String format = "json";
    private String protocol = "local";

    public EsbLocalTest() {
    }

    public String getList() {
        RequestConfig requestConfig = new RequestConfig();
        requestConfig.setAppKey(this.appKey);
        this.serverUrl = "http://127.0.0.1:9090/api/esb/getList";
        requestConfig.setServerUrl(this.serverUrl);
        requestConfig.setSign(Boolean.TRUE);
        requestConfig.setSercetKey(this.sercetKey);
        requestConfig.setUserName(this.userName);
        requestConfig.setPassword(this.password);
        requestConfig.setFormat(this.format);
        EsbService service = EsbManager.getService(this.protocol, requestConfig);
        String response = service.getList();
        return response;
    }

    public String getParams(String eventkey, String transmitType) {
        RequestConfig requestConfig = new RequestConfig();
        requestConfig.setAppKey(this.appKey);
        this.serverUrl = "http://127.0.0.1:9090/api/esb/getParams";
        requestConfig.setServerUrl(this.serverUrl);
        requestConfig.setSign(Boolean.TRUE);
        requestConfig.setSercetKey(this.sercetKey);
        requestConfig.setUserName(this.userName);
        requestConfig.setPassword(this.password);
        requestConfig.setFormat(this.format);
        EsbService service = EsbManager.getService(this.protocol, requestConfig);
        String response = service.getParams(eventkey, transmitType);
        return response;
    }
}
